// Variables
let prev = document.querySelector('.prev');
let next = document.querySelector('.next');
let imgs = document.querySelectorAll('.carousel-img');
let dots = document.querySelectorAll('.dot');
let captions = document.querySelectorAll('.carousel-caption')
let totalImgs = imgs.length;
let imgPosition = 0;

// Event Listeners
//next.addEventListener('click', nextImg);
//prev.addEventListener('click', prevImg);

// Update Position
function updatePosition() {
    //   Images
    for (let img of imgs) {
        img.classList.remove('visible');
        img.classList.add('hidden');
    }
    imgs[imgPosition].classList.remove('hidden');
    imgs[imgPosition].classList.add('visible')
        //   Dots
    for (let dot of dots) {
        dot.className = dot.className.replace(" active", "");
    }
    dots[imgPosition].classList.add('active');
    //   Captions
    for (let caption of captions) {
        caption.classList.remove('visible');
        caption.classList.add('hidden');
    }
    captions[imgPosition].classList.remove('hidden');
    captions[imgPosition].classList.add('visible')
}

// Next Img
function nextImg() {
    if (imgPosition === totalImgs - 1) {
        imgPosition = 0;
    } else {
        imgPosition++;
    }
    updatePosition();
}
//Previous Image
function prevImg() {
    if (imgPosition === 0) {
        imgPosition = totalImgs - 1;
    } else {
        imgPosition--;
    }
    updatePosition();
}

// Dot Position
dots.forEach((dot, dotPosition) => {
    dot.addEventListener("click", () => {
        imgPosition = dotPosition
        updatePosition(dotPosition)
    })
})


const words = ["Enterpreneur", "Industrious", "Elaborate", "Ambitious"]; // An array of words to be used for replacement
const wordDiv = document.getElementById("word"); // Get the div element
let index = 0; // Initialize the index variable

// Set an interval to update the word in the div element every 2 seconds
setInterval(() => {
    wordDiv.textContent = words[index]; // Set the content of the div element to the current word in the array
    index = (index + 1) % words.length; // Increment the index variable and reset it to 0 when it reaches the end of the array
}, 8000);



// Start the animation
var animation = document.getElementById("canvas");


// Stop the animation once the page has finished loading
window.addEventListener('load', function() {
    animation.style.display = "none";
});

// Animation code

// const myElement = document.querySelector('.my-element');
// const myAnimation = gsap.fromTo(myElement, { scale: 0.5 }, { scale: 1 });


// // Get the button and content elements
// const button = document.getElementById('theme-button');
// const content = document.getElementById('content');

// // Add a click event listener to the button
// button.addEventListener('click', function() {
//     // Toggle the "light-theme" and "dark-theme" classes on the content element
//     content.style.backgroundColor = "#dad7cd";
//     content.style.color = "#344e41";

// });
// Get all accordion headers
var accordionHeaders = document.querySelectorAll('.accordion-header');

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}

gsap.registerPlugin(ScrollTrigger);
gsap.from('.hero-img', {
    scrollTrigger: ".hero-img",
    duration: 20,
    opacity: 0,
    scale: 0.4,
    ease: 'bounce'
});

gsap.from(".service-each", {
    scrollTrigger: {
        trigger: ".service-each",
        toggleActions: "restart play none pause"
    },
    duration: 5,
    x: '100%',
    opacity: 0,
    scale: 0.5,
    stagger: 0.5,
    ease: 'power4',

});

// gsap.from(".herotext", {
//     scrollTrigger: {
//         trigger: ".herotext",
//         toggleActions: "restart play none pause"
//     },
//     duration: 2,
//     y: "-100%",
//     opacity: 0.5,
//     stagger: 0.25,
//     scale: 0.4,
//     ease: "slow",
// });
gsap.from(".herte", {
    scrollTrigger: {
        trigger: ".hero",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    y: '100%',
    stagger: 0.25,
    ease: 'slow',
});
gsap.from(".word", {
    scrollTrigger: {
        trigger: ".word",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    y: '-100%',
    stagger: 0.25,
    ease: 'slow',
});
gsap.from(".herbutt", {
    scrollTrigger: {
        trigger: ".herbutt",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    y: '-100%',
    stagger: 0.25,
    ease: 'slow',
});
gsap.from(".skill", {
    scrollTrigger: {
        trigger: ".skill",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    y: '-100%',
    stagger: 0.25,
    ease: 'slow',
});
gsap.from(".service-head", {
    scrollTrigger: {
        trigger: ".service-head",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    x: '-100%',
    stagger: 0.25,
    ease: 'ease',
});
gsap.from(".main-serv", {
    scrollTrigger: {
        trigger: ".main-serv",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    opacity: 0,
    scale: 0.3,
    stagger: 0.25,
    ease: 'slow',
});
gsap.from(".electric-service", {
    scrollTrigger: {
        trigger: ".electric-service",
        toggleActions: "restart play none pause"
    },
    duration: 3,
    opacity: 0,
    scale: 0.3,
    stagger: 0.25,
    ease: 'slow',
});


gsap.from(".direction-r", {
        scrollTrigger: {
            trigger: ".direction-r",
            toggleActions: "restart play none pause"
        },
        duration: 3,
        x: '100%',
        stagger: 1,
        ease: 'slow',

    }

)
gsap.from(".direction-l", {
        scrollTrigger: {
            trigger: ".direction-l",
            toggleActions: "restart play none pause"
        },
        duration: 3,
        x: '-100%',
        stagger: 1,
        ease: 'slow',

    }

)